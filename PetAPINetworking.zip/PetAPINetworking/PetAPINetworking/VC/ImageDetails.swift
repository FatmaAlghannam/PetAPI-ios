//
//  ImageDetails.swift
//  PetAPINetworking
//
//  Created by fatma adnan on 04/03/2024.
//

import Foundation
import UIKit
import Kingfisher

class ImageDetails {
}

